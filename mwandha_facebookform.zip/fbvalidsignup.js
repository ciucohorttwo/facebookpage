var fbvalidsignup = () => {

    const fname = document.getElementById("fname");
    const lname = document.getElementById("lname");
    const moem = document.getElementById("moem");
    const npass = document.getElementById("npass");
    const date = document.getElementById("date");
    const gender = document.getElementById("gender");

    if (fname.value =="")
    {
    alert('Please enter your First Name.');
    emph.style.border = "1px solid red";
    }
    
    if (lname.value =="")
    {
    alert('Please enter your Last Name.');
    emph.style.border = "1px solid red";
    }
    
    if (moem.value =="")
    {
    alert('Please enter your mobile number or email.');
    emph.style.border = "1px solid red";
    }
    
    if (npass.value =="")
    {
    alert('Please enter your new password.');
    emph.style.border = "1px solid red";
    }
    
    /** if (month.value =="" || day.value =="" || year.value =="")
    {
    alert('Please enter date of birth.');
    emph.style.border = "1px solid red";
    } */

    if (!(gendermale.checked) ||!(gendermale.checked) || !(gendermale.checked));
    {
    alert("What is your SEX? None of the GENDER options is selected.");
    }
}