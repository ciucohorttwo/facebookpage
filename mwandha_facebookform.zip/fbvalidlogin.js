var fbvalidlogin = () => {

const emph = document.getElementById("emph");
const pass = document.getElementById("pass");


if (emph.value =="")
{
alert('Please enter your email or phone Number.');
emph.style.border = "1px solid red";
}

if (!emph.value.includes('@') || !email.value.includes('.'))
{
    alert('This is NOT a corret email address format.');
    emph.style.border = "1px solid red";
}

if (emph.value instanceof Number && emph.value.length<10)
{
    alert('This is PHONE Number is too short.');
    emph.style.border = "1px solid red"
}

if (pass.value =="")
{
alert('Please enter your password.');
pass.style.border = "1px solid red";
}
else if (pass.value.length<7 || pass.length>12)
{
    alert('Your password is TOO SHORT. Re-enter using atlease 8 characters');
    pass.style.border = " 2px solid red";
}

else{
    return true;
}
}


